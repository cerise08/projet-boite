-- Khalid GABER
-- ---------- CREATION DE la  Base de Données Gestion des Ventes ------------
Create DATABASE BD_Ventes;
GO
USE BD_Ventes; 
-- --- Création des tables ----------------------

-- ---------- CREATION DES TABLES ------------

CREATE TABLE Employe(
	IdEmploye int PRIMARY KEY,
	Nom VARCHAR(20) NOT NULL,
	Prenom VARCHAR(20),
	DN Date,
	Pays VARCHAR(20)
);

CREATE TABLE Categorie(
	IdCategorie int PRIMARY KEY,
	Nom VARCHAR(20) NOT NULL,
	Description VARCHAR(100)
);

CREATE TABLE Fournisseur(
	IdFournisseur int PRIMARY KEY,
	Societe VARCHAR(255) NOT NULL,
	Contact VARCHAR(255) NOT NULL,
	Fonction VARCHAR(100) NOT NULL,
	Ville VARCHAR(20) NOT NULL,
	Pays VARCHAR(20) NOT NULL
);

CREATE TABLE Produit(
	IdProduit int PRIMARY Key,
	Nom VARCHAR(255) NOT NULL,
	NumFou INT REFERENCES Fournisseur(IdFournisseur) ON DELETE CASCADE,
	NumCategorie INT REFERENCES categorie(IdCategorie)ON DELETE CASCADE,
	Prix DECIMAL(10,2),
	Stock INT CHECK(Stock >=0),
	Indisp INT CHECK(INDISP IN(0,1))
);

CREATE TABLE Client(
	IdClient VARCHAR(20) PRIMARY KEY,
	Societe VARCHAR(255) NOT NULL,
	Contact VARCHAR(20) NOT NULL,
	Fonction VARCHAR(255),
	Ville VARCHAR(20),
	Pays VARCHAR(20) Not null
);

CREATE TABLE Commande(
	IdCommande INT PRIMARY KEY,
	NumClient VARCHAR(20)  REFERENCES Client(IdClient) ON DELETE CASCADE,
	NumEmploye INT REFERENCES Employe(IdEmploye)ON DELETE CASCADE,
	Date_C DATE NOT NULL,
	Date_L DATE,
	Date_E DATE,
	Ville_Liv VARCHAR(20)
);

CREATE TABLE DetailsCommande(
	NumCommande INT REFERENCES commande(IdCommande)ON DELETE CASCADE,
	NumProduit INT REFERENCES produit(IdProduit)ON DELETE CASCADE,
	Quantite INT DEFAULT 1,
	Remise DECIMAL (5,2),
	PRIMARY KEY(NumCommande,NumProduit)
);

-- --------- INSERTION DES VALEURS -----------


INSERT INTO Employe 
(IdEmploye, Nom, Prenom, DN, pays)
VALUES(1,'Leblanc','Marie','1948/12/08','France');
INSERT INTO employe VALUES(2,'Brachman','Andrew','1952-02-19','France');
INSERT INTO employe VALUES(3,'Leclerc','Janet','1963-08-30','France');
INSERT INTO employe VALUES(4,'Durant','Margaret','1937-09-19','France');
INSERT INTO employe VALUES(5,'Dupont','Steven','1955-03-04','Royaume-Uni');
INSERT INTO employe VALUES(6,'Delahaye','Michael','1963-07-02','Royaume-Uni');
INSERT INTO employe VALUES(7,'King','Robert','1960-05-29','Royaume-Uni');
INSERT INTO employe VALUES(8,'Callahan','Laura','1958-01-09','Etats-Unis');
INSERT INTO employe VALUES(9,'Dodsworth','Anne','1966-01-27','Royaume-Uni');



INSERT INTO categorie VALUES(1,'Boissons','Boissons, cafes, thes, bieres');
INSERT INTO categorie VALUES(2,'Condiments','Sauces, assaisonements et epices');
INSERT INTO categorie VALUES(3,'Desserts','Desserts et friandises');
INSERT INTO categorie VALUES(4,'Produits laitiers','Fromages');
INSERT INTO categorie VALUES(5,'Pates et cereales','Pains, biscuits, pates et cereales');
INSERT INTO categorie VALUES(6,'Viandes','Viandes preparees');
INSERT INTO categorie VALUES(7,'Produits secs','Fruits secs, raisins, autres');
INSERT INTO categorie VALUES(8,'Poissons et fr','Poissons, fruits de mer,escargot');



INSERT INTO client VALUES('BLONP','Blondel pere et fils','Frederique Cileaux','Directeur du marketing','Strasbourg','France');
INSERT INTO client VALUES('BONAP','Bon app','Laurence Leblhan','Proprietaire','Marseille','France');
INSERT INTO client VALUES('BOTTM','Bottom-Dollar Markets','Elizabeth London','Chef comptable','Tsawassen','Canada');
INSERT INTO client VALUES('FOLIG','Folies gourmandes','Martine Rance','Representant(e)','Lille','France');
INSERT INTO client VALUES('GREAL','Greal Lakes Food Market','Howard Synder','Directeur du marketing','Eugene','Etats-Unis');
INSERT INTO client VALUES('KOENE','Koniglich Essen','Philip Cramer','Assistant(e) des ventes','Brandenburg','Allemagne');
INSERT INTO client VALUES('LACOR','La corne d''abondance','Daniel Tonini','Representant(e)','Versailles','France');
INSERT INTO client VALUES('LAMAI','La maison d''Asie','Annette Roulet','Chef des ventes','Toulouse','France');
INSERT INTO client VALUES('LONEP','Lonesome Pine Restaurant','Fran Wilson','Chef des ventes','Portland','Etats-Unis');
INSERT INTO client VALUES('MAGAA','Magazzini Alimentari Riuntli','Giovanni Rovelli','Directeur du marketing','Bergamo','Italie');
INSERT INTO client VALUES('PARIS','Paris specialites','Marie Bertrand','Proprietaire','Paris','France');
INSERT INTO client VALUES('SEVES','Seven Seas Import','Hari Kumar','Chef des ventes','London','Royaume-Uni');
INSERT INTO client VALUES('VICTE','Victuailles en stock','Mary Seveley','Assistant(e) des ventes','Lyon','France');
INSERT INTO client VALUES('VINET','Vins et alcools Chevalier','Paul Henriot','Chef comptable','Reims','France');




INSERT INTO commande VALUES(10334,'VICTE',8,'2006-10-18','2006-11-15','2006-10-25','Lyon');
INSERT INTO commande VALUES(10431,'BOTTM',4,'2007-01-27','2007-08-19','2007-02-04','Tsawassen');
INSERT INTO commande VALUES(10436,'BLONP',3,'2007-02-02','2007-03-02','2007-02-08','Strasbourg');
INSERT INTO commande VALUES(10265,'BLONP',2,'2006-07-22','2006-08-19','2006-08-09','Strasbourg');
INSERT INTO commande VALUES(10454,'LAMAI',4,'2007-02-18','2007-03-18','2007-02-22','Toulouse');
INSERT INTO commande VALUES(10457,'KOENE',2,'2007-02-22','2007-03-22','2007-02-28','Brandenburg');
INSERT INTO commande VALUES(10511,'BONAP',4,'2007-04-15','2007-05-13','2007-04-18','Marseille');
INSERT INTO commande VALUES(10523,'SEVES',7,'2007-04-28','2007-05-26','2007-04-30','London');
INSERT INTO commande VALUES(10681,'GREAL',3,'2007-09-22','2007-10-20','2007-09-27','Eugene');

INSERT INTO fournisseur VALUES(1,'Exotic Liquids','Charlotte Cooper','Assistant export','London','Royaume-Uni');
INSERT INTO fournisseur VALUES(2,'New Orleans Cajun Delights','Shelley Burke','Acheteur','New Orleans','Etats-Unis');
INSERT INTO fournisseur VALUES(3,'Grandma Kelly''s Homestead','Regina Murphy','Représentant(e)','Ann Arbor','Etats-Unis');
INSERT INTO fournisseur VALUES(7,'Pavlova, Ltd.','Ian Devling','Directeur du marketing','Melbourne','Australie');
INSERT INTO fournisseur VALUES(8,'Specialty Biscuits, Ltd.','Peter Wilson','Représentant','Manchester','Royaume-Unis');
INSERT INTO fournisseur VALUES(26,'Pasta Buttini s.r.l.','Giovanni Giudici','Acheteur','Salerno','Italie');
INSERT INTO fournisseur VALUES(27,'Escargots Nouveaux','Marie Delamare','Chef des ventes','Montceau','France');
INSERT INTO fournisseur VALUES(28,'Gai pâturage','Eliane Noz','Représentant(e)','Annecy','France');

INSERT INTO produit VALUES(1,'Chai',1,1,13,39,0);
INSERT INTO produit VALUES(2,'Chang',1,1,14.48,17,0);
INSERT INTO produit VALUES(4,'Chef Anton''s Cajun Seasoning',2,2,16.77,53,0);
INSERT INTO produit VALUES(5,'Chef Anton''s Gumbo Mix',2,2,16.27,0,1);
INSERT INTO produit VALUES(6,'Grandma''s Boysenberry Spread',3,2,19,120,0);
INSERT INTO produit VALUES(8,'Northwoods Cranberry Sauce',3,2,30.49,6,0);
INSERT INTO produit VALUES(16,'Pavlova',7,3,13.25,29,0);
INSERT INTO produit VALUES(17,'Alice Mutton',7,6,29.73,0,1);
INSERT INTO produit VALUES(19,'Teatime Chocolate Biscuits',8,3,12,25,0);
INSERT INTO produit VALUES(20,'Sir Rodney''s Marmalade',8,3,7.01,40,0);
INSERT INTO produit VALUES(56,'Gnocchi di nonna Alice',26,5,28.97,21,0);
INSERT INTO produit VALUES(58,'Escargots de Bourgogne',27,8,10.25,62,0);
INSERT INTO produit VALUES(59,'Raclette Courdavault',28,4,41,79,0);
INSERT INTO produit VALUES(60,'Camembert Pierrot',28,4,25.5,19,0);
INSERT INTO produit VALUES(68,'Scottish Longbreads',8,3,9.5,6,0);


INSERT INTO detailsCommande VALUES(10265,17,30,0);
INSERT INTO detailsCommande VALUES(10334,68,10,0);
INSERT INTO detailsCommande VALUES(10431,17,50,0.25);
INSERT INTO detailsCommande VALUES(10436,56,40,0.10);
INSERT INTO detailsCommande VALUES(10454,16,20,0.20);
INSERT INTO detailsCommande VALUES(10457,59,36,0);
INSERT INTO detailsCommande VALUES(10511,4,50,0.15);
INSERT INTO detailsCommande VALUES(10511,8,10,0.15);
INSERT INTO detailsCommande VALUES(10523,17,25,0.10);
INSERT INTO detailsCommande VALUES(10523,20,15,0.10);
INSERT INTO detailsCommande VALUES(10681,19,30,0.10);
INSERT INTO detailsCommande VALUES(10681,20,20,0);
INSERT INTO detailsCommande VALUES(10681,68,30,0.20);
-- --------------------------------------------------